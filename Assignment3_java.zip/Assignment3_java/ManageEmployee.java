class Employee {
String name;
int employeeID;
String department;

Employee(String name, int employeeID, String department){
this.name = name;
this.employeeID = employeeID;
this. department = department;
}
public void setName(String name){
		this.name = name;		
	}
	
	public void setEmployeeID(int employeeID){
		this.employeeID = employeeID;
	}
	
	public void setDepartment(String department){
		this.department = department;
	}
	
	public String getName(){
		System.out.println(name);
		return name;
	}
	
	public int getEmployeeID(){
		System.out.println(employeeID);
		return employeeID;
	}
	 
	public String getDepartment(){
		System.out.println(department);
		return department;
	}
	
public void display(){
	System.out.println("Employee details from Employeeclass: " +name +employeeID +department);
}
 
}

class Manager extends Employee{
	Manager(String name, int employeeID, String department){
	super(name, employeeID, department);
	}
	public void disp(){
	System.out.println("Employee details from Managerclass: " +name +employeeID +department);		
	}
	
	
	
	
	
	Manager(String name , int employeeID){
		super(name, employeeID, " ");
	}
		public void disp1(){
		System.out.println("Employee details from managerclass but from 2nd Constructor: " +name +employeeID);
		}
	
}


class ManageEmployee{
	public static void main(String args[]){
		Employee emp = new Employee("Aakaash", 1234, "Algorithmics");
		//Employee emp1 = new Employee("Aakaash", 1234, "Algorithmics");
		Manager m = new Manager("Anjali", 5432, "IT");
		Manager m1 = new Manager("Abhi", 3432);
		
		
		emp.display();
		m.disp();
		m1.disp1();
		
		
	}
}