class Person{
	String name;
	int age;
	
	Person(String name, int age){
		this.name = name;
		this.age = age;
	}
	
	public void SetName(String Name){
		this.name = name;
	}
	
	public void SetAge(int age){
		this.age = age;
	}
	
	public String GetName() {
		return name;
	}
	
	public int GetAge() {
		return age;
	}
	
	public void ShowDetails(){
		System.out.println("Name :" +name +" Age: " +age +" After Class Person");
	}
}

class Student extends Person{
	String grade;
		Student(String name, int age, String grade){
			super(name, age);
			this.grade = grade;
		}
		
		public void ShowDetails1(){
			System.out.println("After Student 1st Constructor, Name:" + name + " age: " + age + ",Grade: " + grade);
		}
		
		Student(String name, int age)
		{
			super(name, age);
		}
		
		public void ShowDetails2(){
			System.out.println("After 2nd Constructor, Name: " +name+ " Age: " +age);
		}
}

class StudentManagement{
	public static void main(String args[]){
		Person p = new Person("Aakaash", 32);
		
		Student st1 = new Student("Anjali", 21, "A");
		Student st2= new Student("Nutan", 27);
		
		p.ShowDetails();
		st1.ShowDetails1();
		st2.ShowDetails2();
		
		
	}
}