import java.util.*;

class Management {
	private String empname;
	private String empID;
	private String department;
	
	Management(String empname, String id, String department) {
		this.empname = empname ;
		this.empID = id;
		this.department = department;
	}
	
	 String getEmpName() {
		return empname;
	}
	
	public String getEmpId() {
		return empID;
	}
	
	public String getdepartment() {
		return department;
	}
	
	void Setname(String empname) {
		this.empname=empname;
	}
	
	void setEmpId(String empID) {
		this.empID = empID;
	}
	
	void setDepartment(String department) {
		this.department = department;
	}
	public void display() {
		System.out.println("Employee Name: "+ empname + ", EmpID: " + empID +", Department: " +department);
	}
}

public class Employeee {
	private ArrayList<Management> manage;
	
	public Employeee() {
		manage = new ArrayList<>();
	}
	
	public void addEmp(Management emp) {
		manage.add(emp);
		System.out.println("Employee added successfully");
	}
	
	public void updateEmp(String id, String department) {
		boolean found = false;
		for (Management emps : manage) {
			if (emps.getEmpId().equals(id)) {
				emps.setDepartment(department);
				System.out.println("Department updated");
				found = true;
			}
		}
		if (!found) {
			System.out.println("Employee not found");
		}
	}
	
	
	public void removeEmp(String empID) {
		boolean removed = manage.removeIf(emp -> emp.getEmpId().equals(empID));
		if (removed) {
			System.out.println("Employee with id "+ empID + "removed.");
		} else {
			System.out.println("Employee with id "+ empID + "Not found.");
		}
	}
		
	public void displayAllEmployee() {
		if (manage.isEmpty()) {
			System.out.println("No Employess found.");
			return;
		}
		for (Management emp : manage) {
			emp.display();
		}
	}
	
	public static void main(String[] args) {
		Employeee employee = new Employeee();
		Scanner scanner = new Scanner(System.in);
		
		boolean running = true;
		while (running) {
			System.out.println("\n Employee details:");
			System.out.println("1.Add an Employee");
			System.out.println("2.Update employee's department");
			System.out.println("3.Remove Employee");
			System.out.println("4.Display all Employee");
			System.out.println("5.Exit");
			System.out.println("Enter your Choice:");
			int choice = scanner.nextInt();
			scanner.nextLine();
			
			switch (choice) {
				case 1:
					System.out.println("Enter Employee name: ");
					String empname = scanner.nextLine();
					System.out.println("Enter Employee ID :");
					String id = scanner.nextLine();
					System.out.println("Enter Employee Department");
					String dep = scanner.nextLine();
					Management mg =  new Management(empname, id, dep);
					
					employee.addEmp(mg);
					break;
					
				case 2:
					System.out.println("Enter Employee ID: ");
					String idn = scanner.nextLine();
					System.out.println("Enter Employee department to update");
					String de = scanner.nextLine();
					employee.updateEmp(idn, de);
					break;
					
				case 3:
					System.out.println("Enter EmpId to remove");
					String idr = scanner.nextLine();
					employee.removeEmp(idr);
					break;
				
				case 4:
					employee.displayAllEmployee();
					break;
				
				case 5:
					System.out.println("Exiting....");
					running = false;
					break;
					
					
				default:
					System.out.println("Invalid choice");
			}
		}

	}



}
