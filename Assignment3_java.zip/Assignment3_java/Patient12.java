//Assignment-3
//Question-12

import java.util.*;

class Patient {
    private String patientId;
    private String name;
    private String diagnosis;
    private int daysAdmitted;

    public Patient(String patientId, String name, String diagnosis, int daysAdmitted) {
        this.patientId = patientId;
        this.name = name;
        this.diagnosis = diagnosis;
        this.daysAdmitted = daysAdmitted;
    }

    public String getPatientId() {
        return patientId;
    }

    public String getName() {
        return name;
    }

    public String getDiagnosis() {
        return diagnosis;
    }

    public int getDaysAdmitted() {
        return daysAdmitted;
    }

   
    public String toString() {
        return "Patient{" +
                "patientId='" + patientId + '\'' +
                ", name='" + name + '\'' +
                ", diagnosis='" + diagnosis + '\'' +
                ", daysAdmitted=" + daysAdmitted +
                '}';
    }
}

class PatientDatabase {
    private Map<String, Patient> patientMap = new HashMap<>();

    private Map<String, List<Patient>> diagnosisMap = new HashMap<>();

    public boolean addPatient(Patient patient) {
        String id = patient.getPatientId();
        if (patientMap.containsKey(id)) {
            return false;
        }
        patientMap.put(id, patient);

        String diagnosis = patient.getDiagnosis();
        diagnosisMap.computeIfAbsent(diagnosis, k -> new ArrayList<>()).add(patient);

        return true;
    }

    public boolean removePatient(String patientId) {
        Patient patient = patientMap.remove(patientId);
        if (patient == null) {
            return false;
        }

        String diagnosis = patient.getDiagnosis();
        List<Patient> patientsWithDiagnosis = diagnosisMap.get(diagnosis);
        if (patientsWithDiagnosis != null) {
            patientsWithDiagnosis.remove(patient);
            if (patientsWithDiagnosis.isEmpty()) {
                diagnosisMap.remove(diagnosis);
            }
        }
        return true;
    }

    public List<Patient> findPatientsByDiagnosis(String diagnosis) {
        return diagnosisMap.getOrDefault(diagnosis, Collections.emptyList());
    }
}

public class Patient12 {
    public static void main(String[] args) {
        PatientDatabase db = new PatientDatabase();

        Patient p1 = new Patient("45", "Abhishek", "fever", 3);
        Patient p2 = new Patient("18", "Anjali", "cough", 10);
        Patient p3 = new Patient("07", "Akash", "fever", 5);

        db.addPatient(p1);
        db.addPatient(p2);
        db.addPatient(p3);

        System.out.println("Patients with fever:");
        for (Patient p : db.findPatientsByDiagnosis("fever")) {
            System.out.println(p);
        }

        db.removePatient("07");

        System.out.println("\nPatients with fever after removal:");
        for (Patient p : db.findPatientsByDiagnosis("fever")) {
            System.out.println(p);
        }
    }
}
