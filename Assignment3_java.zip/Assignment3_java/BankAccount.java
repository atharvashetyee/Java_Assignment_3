
import java.util.*;

class BankDetail {
	String accname;
	String accno;
	double bal;
	
	BankDetail(String accname, String accno, double bal){
		this.accname = accname;
		this.accno = accno;
		this.bal = bal;
	}
	
	public void deposit(double amount) {
		if (amount > 0) {
			bal += amount;
			System.out.println("Deposited: Rs" + amount);
		}
	}
	
	public void withdraw(double amount) {
		if (amount > 0 && amount <= bal ) {
			bal -= amount;
			System.out.println("Withdrawn amount: Rs" + amount);
		} 
		else {
			System.out.println("Insufficient Balance: Rs" + bal);
		}
	}
	
	String getAccName() {
		return accname;
	}
	
	String getAccNo() {
		return accno;
	}
	
	double getBalance() {
		return bal;
	}

	void setAccName(String accname) {
		this.accname = accname;
	}
	
	void setAccNo(String accno) {
		this.accno = accno;
	}
	
	void setBalance(double bal) {
		this.bal = bal;
	}
	
	void display() {
		System.out.println("Account Holder Name: " + accname + ", Account Number: " + accno + ", Balance: Rs" + bal);
	}
}

public class BankAccount {
	private ArrayList<BankDetail> bank;
	
	public BankAccount() {
		bank = new ArrayList<>(); 
	}
	
	private BankDetail findAccount(String accno) {
		for (BankDetail bd : bank) {
			if (bd.getAccNo().equals(accno)) {
				return bd;
			}
		}
		return null;
	}
	
	public void start() {
		Scanner scanner = new Scanner(System.in);
		boolean running = true ;
		
		bank.add(new BankDetail("Aakaash", "ACC123", 5000.0));
		bank.add(new BankDetail("Balasaheb", "ACC456", 8000.0));
		bank.add(new BankDetail("Anjali", "ACC789", 18000.0));
		
		while (running) {
			System.out.println("\n____Bank Menu____");
			System.out.println("1.Deposit Money to your Account");
			System.out.println("2.Withdraw money from your account");
			System.out.println("3.Display Balance");
			System.out.println("4.Exit");
			System.out.println("Enter your Choice:");
			int choice = scanner.nextInt();
			scanner.nextLine();
			
			switch (choice) {
			case 1: 
				System.out.println("Enter Account Number:");
				String depAcc = scanner.nextLine();
				BankDetail depAccount = findAccount(depAcc);
				if (depAccount != null) {
					System.out.println("Enter amount to deposit:");
					double amount = scanner.nextDouble();
					scanner.nextLine();
					depAccount.deposit(amount);
				} else {
					System.out.println("Account not found.");
				}
				break;
				
			case 2:
				System.out.println("Enter Account Number:");
				String withAcc = scanner.nextLine();
				BankDetail withAccount = findAccount(withAcc);
				if (withAccount != null) {
					System.out.println("Enter amount to withdraw:");
					double amount = scanner.nextDouble();
					scanner.nextLine();
					withAccount.withdraw(amount);
				} else {
					System.out.println("Account not found.");
				}
				break;
				
			case 3:
				System.out.println("Enter Account Number:");
				String balAcc = scanner.nextLine();
				BankDetail balAccount = findAccount(balAcc);
				if (balAccount != null) {
					balAccount.display();
				} else {
					System.out.println("Account not found.");
				}
				break;
				
			case 4:
				System.out.println("Exiting...");
				running = false;
				break;
				
			default:
				System.out.println("Invalid choice.");
			}
		}
	}
	
	public static void main(String[] args) {
		BankAccount ba = new BankAccount();
		ba.start();
	}
}